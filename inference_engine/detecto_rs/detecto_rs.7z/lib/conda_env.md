```
# Name                    Version                   Build  Channel
_libgcc_mutex             0.1                        main
addict                    2.2.1                    pypi_0    pypi
blas                      1.0                         mkl
ca-certificates           2020.1.1                      0
certifi                   2020.4.5.1               py37_0
cudatoolkit               10.1.243             h6bb024c_0
cycler                    0.10.0                   pypi_0    pypi
cython                    0.29.19                  pypi_0    pypi
decorator                 4.4.2                    pypi_0    pypi
freetype                  2.9.1                h8a8886c_1
imageio                   2.8.0                    pypi_0    pypi
instaboostfast            0.1.2                    pypi_0    pypi
intel-openmp              2020.1                      217
jpeg                      9b                   h024ee3a_2
kiwisolver                1.2.0                    pypi_0    pypi
ld_impl_linux-64          2.33.1               h53a641e_7
libedit                   3.1.20181209         hc058e9b_0
libffi                    3.3                  he6710b0_1
libgcc-ng                 9.1.0                hdf63c60_0
libgfortran-ng            7.3.0                hdf63c60_0
libpng                    1.6.37               hbc83047_0
libstdcxx-ng              9.1.0                hdf63c60_0
libtiff                   4.1.0                h2733197_1
lz4-c                     1.9.2                he6710b0_0
matplotlib                3.2.1                    pypi_0    pypi
mkl                       2020.1                      217
mkl-service               2.3.0            py37he904b0f_0
mkl_fft                   1.0.15           py37ha843d7b_0
mkl_random                1.1.1            py37h0573a6f_0
mmcv                      0.5.9                    pypi_0    pypi
mmdet                     1.1.0+3264b1a             dev_0    <develop>
ncurses                   6.2                  he6710b0_1
networkx                  2.4                      pypi_0    pypi
ninja                     1.9.0            py37hfd86e86_0
numpy                     1.18.1           py37h4f9e942_0
numpy-base                1.18.1           py37hde5b4d6_1
olefile                   0.46                     py37_0
opencv-python             4.2.0.34                 pypi_0    pypi
openssl                   1.1.1g               h7b6447c_0
pillow                    6.2.2                    pypi_0    pypi
pip                       20.0.2                   py37_3
pycocotools               2.0                      pypi_0    pypi
pyparsing                 2.4.7                    pypi_0    pypi
python                    3.7.7                hcff3b4d_5
python-dateutil           2.8.1                    pypi_0    pypi
pytorch                   1.4.0           py3.7_cuda10.1.243_cudnn7.6.3_0    pytorch
pywavelets                1.1.1                    pypi_0    pypi
readline                  8.0                  h7b6447c_0
scikit-image              0.17.2                   pypi_0    pypi
scipy                     1.4.1                    pypi_0    pypi
setuptools                46.4.0                   py37_0
six                       1.14.0                   py37_0
sqlite                    3.31.1               h62c20be_1
tifffile                  2020.5.30                pypi_0    pypi
tk                        8.6.8                hbc83047_0
torchvision               0.5.0                py37_cu101    pytorch
wheel                     0.34.2                   py37_0
xz                        5.2.5                h7b6447c_0
yapf                      0.30.0                   pypi_0    pypi
zlib                      1.2.11               h7b6447c_3
zstd                      1.4.4                h0b5b093_3
```
