# GENERATED VERSION FILE
# TIME: Thu Jul 16 15:11:01 2020

__version__ = '1.1.0+unknown'
short_version = '1.1.0'
